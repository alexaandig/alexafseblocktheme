<?php return array('dependencies' => array(), 'version' => '1ae3ce03039fa027ffb5');
