<?php return array('dependencies' => array(), 'version' => '9fbe76327e1138afff70');
