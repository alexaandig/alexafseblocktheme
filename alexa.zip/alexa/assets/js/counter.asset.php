<?php return array('dependencies' => array(), 'version' => '6d81e42901b1803187de');
