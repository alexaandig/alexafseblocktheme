<?php return array('dependencies' => array(), 'version' => '2c3bb7b2614eb6cfda1a');
