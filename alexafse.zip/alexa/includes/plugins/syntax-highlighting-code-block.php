<?php

declare( strict_types=1 );

namespace Alexa\Theme;

add_filter( 'syntax_highlighting_code_block_style', fn() => 'atom-one-light' );
